let currentPassword = null;  // Store the current password
let secretNotes = "";  // Store the user's notes
let mediaFiles = { images: [], videos: [], pdfs: [] };  // Store uploaded media
let maxFiles = { images: 20000, videos: 200, pdfs: 700 };  // Limits for files
let penColor = 'black';  // Default pen color
let penOpacity = 1;  // Default pen opacity
let penSize = 2;  // Default pen size
let eraserEnabled = false;  // To toggle eraser tool

// Function to set the initial password
function setPassword() {
    const newPassword = document.getElementById('new-password').value;
    const errorMessage = document.getElementById('error-message');
    if (newPassword) {
        currentPassword = newPassword;  // Save the password
        document.getElementById('set-password-screen').style.display = 'none';
        document.getElementById('unlock-screen').style.display = 'flex';
    } else {
        errorMessage.style.display = 'block';  // Show error if password is empty
    }
}

// Function to unlock the app with the password
function unlockApp() {
    const enteredPassword = document.getElementById('unlock-code').value;
    const unlockError = document.getElementById('unlock-error');
    if (enteredPassword === currentPassword) {
        document.getElementById('unlock-screen').style.display = 'none';
        document.getElementById('note-screen').style.display = 'flex';
        document.getElementById('secret-notes').value = secretNotes;  // Load saved notes
        updateWordCount();
    } else {
        unlockError.style.display = 'block';  // Show error if password is incorrect
    }
}

// Update word count in the notes textarea
function updateWordCount() {
    const noteText = document.getElementById('secret-notes').value;
    const wordCount = noteText.length;
    document.getElementById('word-count').innerText = `${wordCount}/220000`;
}

// Function to save notes to localStorage
function saveNote() {
    secretNotes = document.getElementById('secret-notes').value;
    localStorage.setItem('secretNotes', secretNotes);
    alert('Your note has been saved!');
}

// Function to change password
function changePassword() {
    const newPassword = prompt("Enter new password:");
    if (newPassword) {
        currentPassword = newPassword;  // Update the password
        alert("Password has been changed.");
    }
}

// Function to logout from the app
function logoutApp() {
    document.getElementById('note-screen').style.display = 'none';
    document.getElementById('unlock-screen').style.display = 'flex';
    document.getElementById('unlock-code').value = '';  // Clear code field
}

// Function to handle media upload (photo, video, pdf)
function handleMediaUpload(event) {
    const file = event.target.files[0];
    const mediaContainer = document.getElementById('media-container');

    if (file) {
        if (file.type.startsWith('image/') && mediaFiles.images.length < maxFiles.images) {
            const reader = new FileReader();
            reader.onload = function(e) {
                const img = document.createElement('img');
                img.src = e.target.result;
                mediaContainer.appendChild(img);
                mediaFiles.images.push(file);
            };
            reader.readAsDataURL(file);
        } else if (file.type.startsWith('video/') && mediaFiles.videos.length < maxFiles.videos) {
            const reader = new FileReader();
            reader.onload = function(e) {
                const video = document.createElement('video');
                video.src = e.target.result;
                video.controls = true;
                mediaContainer.appendChild(video);
                mediaFiles.videos.push(file);
            };
            reader.readAsDataURL(file);
        } else if (file.type === 'application/pdf' && mediaFiles.pdfs.length < maxFiles.pdfs) {
            const fileReader = new FileReader();
            fileReader.onload = function(e) {
                const pdf = document.createElement('a');
                pdf.href = e.target.result;
                pdf.download = file.name;
                pdf.innerText = "Download PDF";
                mediaContainer.appendChild(pdf);
                mediaFiles.pdfs.push(file);
            };
            fileReader.readAsDataURL(file);
        } else {
            alert('File limit reached or unsupported file type.');
        }
    }
}

// Enable the eraser tool
function enableEraser() {
    eraserEnabled = !eraserEnabled;
    alert(eraserEnabled ? 'Eraser enabled' : 'Eraser disabled');
}

// Event listener for pen color selection
document.getElementById('pen-color').addEventListener('change', (event) => {
    penColor = event.target.value;
});

// Event listener for pen opacity selection
document.getElementById('pen-opacity').addEventListener('input', (event) => {
    penOpacity = event.target.value;
});

// Event listener for pen size selection
document.getElementById('pen-size').addEventListener('input', (event) => {
    penSize = event.target.value;
});

// Add event listener for media upload
document.getElementById('upload-media').addEventListener('change', handleMediaUpload);
